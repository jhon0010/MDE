package edu.uniandes.co.jee.ejb;
			
public class BolsaDeEmpleoEJB 
{
	
	public void BolsaDeEmpleo (){
	
		
	}
	
	
	public ArrayList<E> darAspirantes (){
	
		
	}
	
	
	public void ordenarPorNombre (){
	
		
	}
	
	
	public void ordenarPorEdad (){
	
		
	}
	
	
	public void ordenarPorProfesion (){
	
		
	}
	
	
	public void ordenarPorAniosDeExperiencia (){
	
		
	}
	
	
	public int buscarAspirante (String nombre){
	
		
	}
	
	
	public int buscarBinarioPorNombre (String nombre){
	
		
	}
	
	
	public boolean agregarAspirante (String nombreA,String profesionA,int aniosExperienciaA,int edadA,String telefonoA,String imagenA){
	
		
	}
	
	
	public int buscarAspiranteMasJoven (){
	
		
	}
	
	
	public int buscarAspiranteMayorEdad (){
	
		
	}
	
	
	public int buscarAspiranteMayorExperiencia (){
	
		
	}
	
	
	public boolean contratarAspirante (String nombre){
	
		
	}
	
	
	public int eliminarAspirantesPorExperiencia (int aniosExperiencia){
	
		
	}
	
	
	public void verificarInvariante (){
	
		
	}
	
	
	public boolean buscarAspirantesConNombresRepetidos (){
	
		
	}
	
	
	public String metodo1 (){
	
		
	}
	
	
	public String metodo2 (){
	
		
	}
	
	
}	
