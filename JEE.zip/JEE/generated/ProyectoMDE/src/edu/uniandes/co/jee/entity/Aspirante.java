package edu.uniandes.co.jee.entity;
			
public class Aspirante 
{
	
	private String nombre;	
	private String profesion;	
	private int aniosExperiencia;	
	private int edad;	
	private String telefono;	
	private String imagen;	
	
	
	public Aspirante ()
	{
		
	}
	
 
	public String getNombre()
	{
		return this.nombre;
	}
	
	public void setNombre(String nombre)
	{
		this.nombre=nombre;
	}
	
 
	public String getProfesion()
	{
		return this.profesion;
	}
	
	public void setProfesion(String profesion)
	{
		this.profesion=profesion;
	}
	
 
	public int getAniosExperiencia()
	{
		return this.aniosExperiencia;
	}
	
	public void setAniosExperiencia(int aniosExperiencia)
	{
		this.aniosExperiencia=aniosExperiencia;
	}
	
 
	public int getEdad()
	{
		return this.edad;
	}
	
	public void setEdad(int edad)
	{
		this.edad=edad;
	}
	
 
	public String getTelefono()
	{
		return this.telefono;
	}
	
	public void setTelefono(String telefono)
	{
		this.telefono=telefono;
	}
	
 
	public String getImagen()
	{
		return this.imagen;
	}
	
	public void setImagen(String imagen)
	{
		this.imagen=imagen;
	}
	
		
}	
