package edu.uniandes.co.jee.service;
			
public class BolsaDeEmpleoService 
{
	
    @GET
    @Path
	public void BolsaDeEmpleo (){
	
		
	}
	
	
    @GET
    @Path
	public ArrayList<E> darAspirantes (){
	
		
	}
	
	
    @GET
    @Path
	public void ordenarPorNombre (){
	
		
	}
	
	
    @GET
    @Path
	public void ordenarPorEdad (){
	
		
	}
	
	
    @GET
    @Path
	public void ordenarPorProfesion (){
	
		
	}
	
	
    @GET
    @Path
	public void ordenarPorAniosDeExperiencia (){
	
		
	}
	
	
    @GET
    @Path
	public int buscarAspirante (String nombre){
	
		
	}
	
	
    @GET
    @Path
	public int buscarBinarioPorNombre (String nombre){
	
		
	}
	
	
    @POST
    @Path
	public boolean agregarAspirante (String nombreA,String profesionA,int aniosExperienciaA,int edadA,String telefonoA,String imagenA){
	
		
	}
	
	
    @GET
    @Path
	public int buscarAspiranteMasJoven (){
	
		
	}
	
	
    @GET
    @Path
	public int buscarAspiranteMayorEdad (){
	
		
	}
	
	
    @GET
    @Path
	public int buscarAspiranteMayorExperiencia (){
	
		
	}
	
	
    @GET
    @Path
	public boolean contratarAspirante (String nombre){
	
		
	}
	
	
    @DELETE
    @Path
	public int eliminarAspirantesPorExperiencia (int aniosExperiencia){
	
		
	}
	
	
    @GET
    @Path
	public void verificarInvariante (){
	
		
	}
	
	
    @GET
    @Path
	public boolean buscarAspirantesConNombresRepetidos (){
	
		
	}
	
	
    @GET
    @Path
	public String metodo1 (){
	
		
	}
	
	
    @GET
    @Path
	public String metodo2 (){
	
		
	}
	
	
}	
