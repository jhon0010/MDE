CREATE TABLE Client
(
)
CREATE TABLE Producto
(
)
CREATE TABLE Carrito
(
)
CREATE TABLE Carritoitem
(
)
CREATE TABLE Item
(
)
